import WelcomeScreen from "@/components/onboarding/welcome/WelcomeScreen";

export default function Index() {
  

  return (
    <WelcomeScreen />
  );
}
