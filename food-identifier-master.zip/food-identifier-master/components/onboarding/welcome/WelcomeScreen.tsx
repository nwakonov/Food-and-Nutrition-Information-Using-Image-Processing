import React, { useState } from 'react';
import {
  View,
  Text,
  StatusBar,
  StyleSheet,
  Dimensions,
  Button,
  Image,
  ActivityIndicator,
  Alert,
  Platform,
  ScrollView, // Added for scrollable content
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import axios from 'axios';
// Svg imports are not used in the provided logic, so they are commented out.
// import Svg, { Defs, RadialGradient, Stop, Rect } from 'react-native-svg';

const { width, height } = Dimensions.get('window');

// Define a more comprehensive type for the prediction result
type PredictionResult = {
  predictions: {
    [key: string]: number; // Food name mapped to probability
  };
  preparation: string; // Method of preparation from OpenAI
  healthBenefits: string[]; // List of health benefits from OpenAI
  error?: string; // Optional error message
};

const WelcomeScreen: React.FC = () => {
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  // Function to show custom alert messages instead of native alert()
  const showAlert = (title: string, message: string) => {
    Alert.alert(title, message, [{ text: "OK" }]);
  };

  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      showAlert("Permission Required", "Permission required to access media library.");
      return;
    }

    const pickerResult = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images, // Ensure only images are picked
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7, // Reduce quality to decrease file size for upload
    });

    if (!pickerResult.canceled && pickerResult.assets?.length > 0) {
      const asset = pickerResult.assets[0];
      setImageUri(asset.uri);
      classifyImage(asset.uri);
    }
  };

  const takePhoto = async () => {
    const permissionResult = await ImagePicker.requestCameraPermissionsAsync();
    if (!permissionResult.granted) {
      showAlert("Permission Required", "Permission required to use camera.");
      return;
    }

    const pickerResult = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images, // Ensure only images are picked
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7, // Reduce quality to decrease file size for upload
    });

    if (!pickerResult.canceled && pickerResult.assets?.length > 0) {
      const asset = pickerResult.assets[0];
      setImageUri(asset.uri);
      classifyImage(asset.uri);
    }
  };

  const classifyImage = async (uri: string) => {
    setLoading(true);
    setResult(null);

    const formData = new FormData();
    const filename = uri.split('/').pop();
    const fileType = filename?.split('.').pop() === 'png' ? 'image/png' : 'image/jpeg';

    formData.append('file', {
      uri: Platform.OS === 'android' ? uri : uri.replace('file://', ''),
      name: filename || 'image.jpg',
      type: fileType,
    } as any);

    try {
      // IMPORTANT: Replace 'http://192.168.1.XX:8000' with your actual server IP or domain
      // If running on an Android emulator, 'localhost' refers to the emulator itself,
      // you'll need your computer's local IP address (e.g., 'http://192.168.1.XX:8000')
      // If running on a physical device, ensure your device and computer are on the same network
      const response = await axios.post<PredictionResult>("http://192.168.138.233:8000/predict", formData, { // REPLACE WITH YOUR IP
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        timeout: 60000, // Increased timeout for potentially longer OpenAI responses (60 seconds)
      });
      setResult(response.data);
    } catch (error: any) {
      console.error("Classification error:", error);
      if (axios.isAxiosError(error) && error.response) {
        console.error("Server Response Error:", error.response.data);
        setResult({
          predictions: {}, // Empty predictions on error
          preparation: "N/A",
          healthBenefits: [],
          error: `Server Error: ${JSON.stringify(error.response.data)}`,
        });
      } else if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
        setResult({
          predictions: {},
          preparation: "N/A",
          healthBenefits: [],
          error: "Request timed out. Please try again.",
        });
      } else {
        setResult({
          predictions: {},
          preparation: "N/A",
          healthBenefits: [],
          error: "Failed to classify image. Please check server connection.",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.outerContainer}>
      <StatusBar barStyle="dark-content" backgroundColor="transparent" translucent />
      {/* ScrollView added to ensure content is scrollable on smaller screens */}
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <View style={styles.container}>
          <Text style={styles.title}>Food Recognition App</Text>
          <Text style={styles.subtitle}>Identify your food and get insights!</Text>

          <View style={styles.buttonContainer}>
            <Button title="Pick from Gallery" onPress={pickImage} color="#66a6ff" />
            <View style={{ width: 10 }} />
            <Button title="Take a Photo" onPress={takePhoto} color="#010101" />
          </View>

          {imageUri && (
            <View style={styles.imagePreviewContainer}>
              <Image source={{ uri: imageUri }} style={styles.image} />
              <Text style={styles.imageCaption}>Uploaded Image</Text>
            </View>
          )}

          {loading && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#66a6ff" />
              <Text style={styles.loadingText}>Classifying food and fetching details...</Text>
            </View>
          )}

          {result && (
            <View style={styles.resultContainer}>
              {result.error ? (
                <Text style={styles.errorText}>Error: {result.error}</Text>
              ) : (
                <>
                  <Text style={styles.resultTitle}>Prediction Results:</Text>
                  {Object.entries(result.predictions).map(([food, probability]) => (
                    <Text key={food} style={styles.predictionItem}>
                      <Text style={styles.foodName}>{food.replace(/_/g, ' ').toUpperCase()}</Text>: {probability.toFixed(2)}
                    </Text>
                  ))}

                  {result.preparation && result.preparation !== "N/A" && (
                    <View style={styles.infoSection}>
                      <Text style={styles.infoTitle}>Preparation Method:</Text>
                      <Text style={styles.infoText}>{result.preparation}</Text>
                    </View>
                  )}

                  {result.healthBenefits && result.healthBenefits.length > 0 && result.healthBenefits[0] !== "N/A" && (
                    <View style={styles.infoSection}>
                      <Text style={styles.infoTitle}>Health Benefits:</Text>
                      {result.healthBenefits.map((benefit, index) => (
                        <Text key={index} style={styles.infoText}>• {benefit}</Text>
                      ))}
                    </View>
                  )}
                </>
              )}
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  outerContainer: {
    flex: 1,
    backgroundColor: '#f0f4f8', // Light background color
  },
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20, // Add vertical padding for scrollable content
  },
  container: {
    width: '100%', // Ensure container takes full width
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 30,
    textAlign: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '80%',
    marginBottom: 20,
  },
  imagePreviewContainer: {
    marginTop: 20,
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  image: {
    width: width * 0.6, // Responsive width
    height: width * 0.6, // Keep aspect ratio
    borderRadius: 10,
    resizeMode: 'cover',
  },
  imageCaption: {
    marginTop: 10,
    fontSize: 14,
    color: '#555',
  },
  loadingContainer: {
    marginTop: 30,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  resultContainer: {
    marginTop: 30,
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
    width: '90%',
    alignItems: 'center',
  },
  resultTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  predictionItem: {
    fontSize: 18,
    color: '#444',
    marginBottom: 5,
  },
  foodName: {
    fontWeight: 'bold',
    color: '#007bff',
  },
  infoSection: {
    marginTop: 20,
    width: '100%',
    paddingHorizontal: 10,
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 16,
    color: '#555',
    lineHeight: 24,
    marginBottom: 4,
  },
  errorText: {
    fontSize: 16,
    color: 'red',
    textAlign: 'center',
  },
});

export default WelcomeScreen;